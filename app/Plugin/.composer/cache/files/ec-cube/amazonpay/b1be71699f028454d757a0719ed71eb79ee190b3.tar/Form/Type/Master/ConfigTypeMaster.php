<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.3   |
    |              on 2020-11-16 14:57:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
namespace Plugin\AmazonPay\Form\Type\Master;class ConfigTypeMaster{const ACCOUNT_MODE = array('SHARED' => 1, 'OWNED' => 2);const ENV = array('SANDBOX' => 1, 'PROD' => 2);const SALE = array('AUTORI' => 1, 'CAPTURE' => 2);const CART_BUTTON_PLACE = array('AUTO' => 1, 'MANUAL' => 2);const PRODUCTS_BUTTON_PLACE = array('AUTO' => 1, 'MANUAL' => 2);}